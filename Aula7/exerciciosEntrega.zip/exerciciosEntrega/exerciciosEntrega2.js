let result = document.getElementById("acao")
const formula = ()=>{
    let nomeForm = window.prompt("Qual é o seu nome?")
    let idadeForm = window.prompt("Qual é a sua idade?")
    alert(`Obrigador por nos passar essas informações, ${nomeForm} de ${idadeForm} anos`)
}